/**
 * Created by Administrator on 2017/3/21.
 */
angular.module('services', [])
    .factory('LoginService',[function(){
        var isLogin = false;

        return{
            set: function(){
                isLogin=!isLogin;
            },

            get: function(){
                return isLogin;
            }

        }
    }])

